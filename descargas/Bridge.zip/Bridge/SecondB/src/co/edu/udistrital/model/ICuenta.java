package co.edu.udistrital.model;

public interface ICuenta {
	
	void enviarD(String monto);

}
