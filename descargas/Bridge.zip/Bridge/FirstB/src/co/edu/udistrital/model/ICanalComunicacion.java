package co.edu.udistrital.model;

public interface ICanalComunicacion {
	//Metodo que permite el envio del mensaje 
	void enviar (String mensaje);

}
