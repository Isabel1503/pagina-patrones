package co.edu.udistrital.model;

public interface IPlataforma {
	//Declara el metodo para recibir un parametro fecha y mostrar el horario de la reunión
	void programar(String fecha);

}
