package co.edu.udistrital.model.concreto;

import co.edu.udistrital.model.Carro;

public class Bmw extends Carro{

	@Override
	protected Object ensablarmotor() {
		return "Ensamblando motor V8 de gasolina de alto rendimiento y tecnología avanzada\n";
	}
	

}
