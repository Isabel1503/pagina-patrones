package co.edu.udistrital.model.concreto;

import co.edu.udistrital.model.Carro;

public class Volkswagen extends Carro{

	@Override
	protected Object ensablarmotor() {
		// TODO Auto-generated method stub
		return "Ensamblando motor V6 de gasolina y diésel\n";
	}
	

}
