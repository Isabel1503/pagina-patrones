package co.edu.udistrital.model.concreto;

import co.edu.udistrital.model.Bebida;

public class Cafe extends Bebida {

	//Método que permite agrgar el Café
	@Override
	protected Object agregarIngrediente() {
		return "Agegando Café \n";
	}

	
	
	

}
