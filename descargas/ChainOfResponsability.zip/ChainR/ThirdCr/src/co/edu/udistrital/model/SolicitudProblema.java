package co.edu.udistrital.model;

public class SolicitudProblema {
	private int escala;

    public SolicitudProblema(int escala) {
        this.escala = escala;
    }

    public double getEscala() {
        return escala;
    }

}
