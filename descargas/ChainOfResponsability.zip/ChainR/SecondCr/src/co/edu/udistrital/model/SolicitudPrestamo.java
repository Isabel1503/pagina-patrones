package co.edu.udistrital.model;

public class SolicitudPrestamo {
	private double monto;

    public SolicitudPrestamo(double monto) {
        this.monto = monto;
    }

    public double getMonto() {
        return monto;
    }

}
