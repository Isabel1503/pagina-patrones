package co.edu.udistrital.model;

public class SolicitudCompra {
	private double monto;

    public SolicitudCompra(double monto) {
        this.monto = monto;
    }

    public double getMonto() {
        return monto;
    }

}
