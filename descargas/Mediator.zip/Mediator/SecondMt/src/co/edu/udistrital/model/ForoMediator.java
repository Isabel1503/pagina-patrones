package co.edu.udistrital.model;

public interface ForoMediator {
	void enviarMensaje(String mensaje, Usuario usuario);
    void agregarUsuario(Usuario usuario);

}
