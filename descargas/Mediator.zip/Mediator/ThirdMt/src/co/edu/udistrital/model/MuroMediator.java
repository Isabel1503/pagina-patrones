package co.edu.udistrital.model;

public interface MuroMediator {
	void enviarMensaje(String mensaje, Editor editor);
    void agregarEditor(Editor editor);

}
