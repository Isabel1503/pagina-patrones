package co.edu.udistrital.model;

public interface TipoPersonaje {
	String mostrar(int x, int y);

}
