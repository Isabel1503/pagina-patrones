package co.edu.udistrital.model;

public interface TipoArbol {
	String mostrar(int x, int y);

}
