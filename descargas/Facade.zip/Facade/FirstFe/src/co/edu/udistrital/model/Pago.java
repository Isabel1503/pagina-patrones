package co.edu.udistrital.model;

//Clase que simula el procesamiento del pago
public class Pago {
	public String procesarPago(double monto) {
		return"Pago procesado: $" + monto;
	}

}
