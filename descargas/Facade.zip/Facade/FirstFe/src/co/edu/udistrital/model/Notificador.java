package co.edu.udistrital.model;

public class Notificador {
	// Método que simula el envío de una confirmación al cliente
	public String enviarConfirmacion(String producto) {
        return "Confirmación enviada para: " + producto;
    }

}
