package co.edu.udistrital.model;

public class Inventario {
	// Método que simula la verificación de disponibilidad de productos
	public boolean verificarProducto(String producto) {
        return true;
    }

    public String mensajeVerificacion(String producto) {
        return "Verificando disponibilidad de: " + producto;
    }

}
