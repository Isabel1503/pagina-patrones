package co.edu.udistrital.model;

public class Verificacion {
	// Método que simula la verificación de la contraseña anterior
	public boolean verificarProducto(String contrasena) {
        return true;
    }

    public String mensajeVerificacion(String contrasena) {
        return "Verificando contraseña anterior: " + contrasena;
    }

}
