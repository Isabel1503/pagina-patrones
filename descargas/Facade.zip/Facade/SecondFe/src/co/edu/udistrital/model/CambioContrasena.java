package co.edu.udistrital.model;

//Clase que simula la entrada de la nueva contraseña
public class CambioContrasena {
	public String cambiarContraseña(String contrasenaN) {
		return"Ingrese la nueva contraseña: " + contrasenaN;
	}

}
