package co.edu.udistrital.model;

public class Notificador {
	// Método que simula el envío de una confirmación al user
	public String enviarConfirmacion(String contrasena) {
        return "Cambiando contraseña " + contrasena;
    }

}
