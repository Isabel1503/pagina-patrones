package co.edu.udistrital.model;

public class Notificador {
	// Método que simula el envío de una confirmación al user
	public String enviarConfirmacion(String cuenta) {
        return "Confirmación enviada para: " + cuenta;
    }

}
