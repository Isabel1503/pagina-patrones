package co.edu.udistrital.model;

public class Almacenamiento {
	// Método que simula la verificación el número de cuenta
	public boolean verificarCuenta(String cuenta) {
        return true;
    }

    public String mensajeVerificacion(String cuenta) {
        return "Verificando número de cuenta: " + cuenta;
    }

}
