package co.edu.udistrital.model;

public interface Orden {
	
	//Método que deben implementar las ordenes
	String ejecutar();

}
