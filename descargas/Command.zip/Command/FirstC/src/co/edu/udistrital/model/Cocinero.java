package co.edu.udistrital.model;

public class Cocinero {
	
	//Lógica de negocio
	
	public String prepararCafe() {
		return"Preparando.. Cafe";
	}
	
	public String prepararTe(){
		return"Preparando.. Té";
	}

}
