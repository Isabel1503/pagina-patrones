package co.edu.udistrital.model;

public class Televisor {//Receptor
	
	//Método que enciende el tv
	public String encender() {
		return"Encendiendo el televisor";
	}

}
