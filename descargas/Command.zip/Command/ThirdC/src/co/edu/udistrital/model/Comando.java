package co.edu.udistrital.model;

public interface Comando {
	
	//Metodo que permite ejecutar una acción en cada clase 
	String ejecutar();

}
