package co.edu.udistrital.model;

public class Radio {//Receptor
	
	//Método que enciende el radio
	public String apagar() {
		return"Apagando radio";
		
	}

}
