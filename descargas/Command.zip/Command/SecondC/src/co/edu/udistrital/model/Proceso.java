package co.edu.udistrital.model;

public interface Proceso {
	
	//Método que deben implementar los pedidos
	String ejecutar();

}
