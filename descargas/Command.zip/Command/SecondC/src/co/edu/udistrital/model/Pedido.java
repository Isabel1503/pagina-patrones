package co.edu.udistrital.model;

public class Pedido {
	
	//Lógica de negocio
	public String realizar() {
		return"Pedido realizado con exito";	
		}
	
	public String Cancelar(){
		return"Pedido cancelado";
		
	}
	
	public String pagar() {
		return"Pedido con pago efectuado";
	}
	

}
