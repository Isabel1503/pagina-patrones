package co.edu.udistrital.controller;

public interface Serie {
	String ver();

}
