package co.edu.udisrital.view;

public class AplMain {
	//Método principal 
	public static void main(String[]args) {
		
		Controller control;
		control = new Controller();
		control.run();
		}
}

