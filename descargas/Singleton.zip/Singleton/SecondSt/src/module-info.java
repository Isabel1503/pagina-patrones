/**
 * 
 */
/**
 * 
 */
module SecondExerSingleton {
}