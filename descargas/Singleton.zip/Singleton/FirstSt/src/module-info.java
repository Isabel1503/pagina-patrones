/**
 * 
 */
/**
 * 
 */
module FirstExerSingleton {
}