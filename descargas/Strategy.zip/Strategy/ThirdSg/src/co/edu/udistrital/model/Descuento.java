package co.edu.udistrital.model;

public interface Descuento {
	//Método que recibe un monto de dinero y devuelve el descuento según el objeto
	double Descontar(double monto); 

}
