package co.edu.udistrital.model;

public interface Movimiento {
	
	//Método que devuelve un String
	String mover();

}
