package co.edu.udistrital.model;

public interface MetodoPago {
	//Método que recibe un monto y retorno un mensaje
	String cancelar(double monto );

}
