package co.edu.udistrital.model.fabricaAbstracta;

public interface ServicioFactory {
	
	ServicioPorcentaje crearPorcentaje();

}
