package co.edu.udistrital.model.fabricaAbstracta;

public interface ServicioPorcentaje {
	
	double validarGanancia(double ganancia);
}
