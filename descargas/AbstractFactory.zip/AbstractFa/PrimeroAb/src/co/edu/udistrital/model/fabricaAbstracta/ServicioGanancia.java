package co.edu.udistrital.model.fabricaAbstracta;

public interface ServicioGanancia {
	String validarIngresos();
	String validarGastos();

}
