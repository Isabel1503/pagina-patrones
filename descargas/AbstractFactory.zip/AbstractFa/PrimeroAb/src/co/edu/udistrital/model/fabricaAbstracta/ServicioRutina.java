package co.edu.udistrital.model.fabricaAbstracta;

public interface ServicioRutina {
	String validarobjetivo();
	String validarPeso();
	

}
