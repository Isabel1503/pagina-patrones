
module AbstractFaSecond {
}