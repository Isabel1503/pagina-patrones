package co.edu.udistrital.controller;

public class AplMain {
	public static void main(String[] ags) {
		
		Controller control;
		control = new Controller();
		control.run();
	}

}
