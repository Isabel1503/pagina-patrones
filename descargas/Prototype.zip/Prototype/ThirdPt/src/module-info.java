/**
 * 
 */
/**
 * 
 */
module Third_Prototype {
}