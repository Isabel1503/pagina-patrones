/**
 * 
 */
/**
 * 
 */
module Fisrt_Prototype {
}