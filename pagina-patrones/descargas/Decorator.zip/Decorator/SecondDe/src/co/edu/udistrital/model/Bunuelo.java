package co.edu.udistrital.model;

public class Bunuelo implements Snack{

	//Métodos implementados de la clase principal Snack
	@Override
	public String getDescripcion() {
		// TODO Auto-generated method stub
		return "Buñuelo";
	}

	@Override
	public double getCosto() {
		// TODO Auto-generated method stub
		return 2500;
	}
	

}
