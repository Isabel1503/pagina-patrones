package co.edu.udistrital.model;

public class Dona implements Snack{
	
	//Métodos implementados de la clase principal Snack

	@Override
	public String getDescripcion() {
		// TODO Auto-generated method stub
		return "Dona";
	}

	@Override
	public double getCosto() {
		// TODO Auto-generated method stub
		return 3500;
	}

}
