package co.edu.udistrital.model;

public class Cafe implements Bebida{

	////Métodos implementados de la clase principal Snack
	@Override
	public String getDescripcion() {
		// TODO Auto-generated method stub
		return "Café";
	}

	@Override
	public double getCosto() {
		// TODO Auto-generated method stub
		return 2500;
	}
	

}
