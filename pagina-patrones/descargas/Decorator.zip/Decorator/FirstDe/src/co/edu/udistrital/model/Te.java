package co.edu.udistrital.model;

public class Te implements Bebida{

	@Override
	public String getDescripcion() {
		// TODO Auto-generated method stub
		return "Té";
	}

	@Override
	public double getCosto() {
		// TODO Auto-generated method stub
		return 3000;
	}

}
