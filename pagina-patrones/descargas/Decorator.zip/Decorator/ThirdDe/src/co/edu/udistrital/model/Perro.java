package co.edu.udistrital.model;

public class Perro implements ComidaRapida{
	
	//Métodos implementados de la clase principal Comida Rápida

	@Override
	public String getDescripcion() {
		// TODO Auto-generated method stub
		return "Perro";
	}

	@Override
	public double getCosto() {
		// TODO Auto-generated method stub
		return 3500;
	}

}
