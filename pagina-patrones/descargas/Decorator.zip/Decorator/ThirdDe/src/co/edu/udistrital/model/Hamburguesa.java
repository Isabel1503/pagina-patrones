package co.edu.udistrital.model;

public class Hamburguesa implements ComidaRapida{

	//Métodos implementados de la clase principal comida Rápida
	@Override
	public String getDescripcion() {
		// TODO Auto-generated method stub
		return "Hamburguesa";
	}

	@Override
	public double getCosto() {
		// TODO Auto-generated method stub
		return 2500;
	}
	

}
