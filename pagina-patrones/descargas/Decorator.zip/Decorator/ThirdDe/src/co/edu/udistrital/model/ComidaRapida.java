package co.edu.udistrital.model;

public interface ComidaRapida {
	//Método para optener el nombre
	String getDescripcion();
	
	//Método para optener el costo
    double getCosto();
    

}
