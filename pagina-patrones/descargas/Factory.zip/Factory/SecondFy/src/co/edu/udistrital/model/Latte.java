package co.edu.udistrital.model;

public class Latte {

}
