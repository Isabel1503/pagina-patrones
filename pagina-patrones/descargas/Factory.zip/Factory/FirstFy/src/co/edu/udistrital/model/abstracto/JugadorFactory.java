package co.edu.udistrital.model.abstracto;

public interface JugadorFactory {
	Jugador crearTipoJugador(String apodo,int numjuego);

}
