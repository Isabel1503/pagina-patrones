package co.edu.udistrital.model.abstracto;

public interface CoffeFactory {
	Coffe CrearOrden(String tipo, int cantidad);

}
