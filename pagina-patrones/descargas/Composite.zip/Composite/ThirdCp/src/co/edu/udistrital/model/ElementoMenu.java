package co.edu.udistrital.model;

public interface ElementoMenu {
	
	//Método que muestra la organización
	String mostrar(String identacion);
	//Método que muestra el nombre del menu
	String getNombre();

}
