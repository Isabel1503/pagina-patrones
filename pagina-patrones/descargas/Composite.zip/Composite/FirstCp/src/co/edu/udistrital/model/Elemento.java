package co.edu.udistrital.model;

public interface Elemento {
	
	//Método que muestra el tipo del elemento
	String mostrar(String referencia);
	//Método que muestra el nombre del elemento
	String getNombre();

}
