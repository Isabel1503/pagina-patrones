package co.edu.udistrital.model;

public interface ElementoEmpresa {
	
	//Método que muestra la jerarquia
	String mostrar(String identacion);
	//Método que muestra el nombre de la persona
	String getNombre();

}
