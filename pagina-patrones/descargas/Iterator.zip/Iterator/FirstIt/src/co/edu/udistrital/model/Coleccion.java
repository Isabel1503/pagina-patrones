package co.edu.udistrital.model;

public interface Coleccion {
	Iterador crearIterador();

}
