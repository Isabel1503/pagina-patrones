package co.edu.udistrital.model;

//libreria externa que solo procesa Json y no xml
public class LibreriaJson {
	
	/*Método( incompatible con la interface) que toma un String en formato json
	 y devuelve un resultado procesado */
	String AnalizadorJson(String json) {
		return "Datos procesados:" +json;
	}

}
