package co.edu.udistrital.model;

//Interface con la que trabaja el cliente
public interface XmlAnalizador {
	
	//Este método recibe un String y lo formateado como xlm
	String AnalizadorXml(String info);

}
