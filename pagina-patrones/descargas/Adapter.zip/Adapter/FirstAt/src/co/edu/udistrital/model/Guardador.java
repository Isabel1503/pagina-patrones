package co.edu.udistrital.model;

public interface Guardador {
	
	//Definición del método guardar
	String guardar(String datos);

}
