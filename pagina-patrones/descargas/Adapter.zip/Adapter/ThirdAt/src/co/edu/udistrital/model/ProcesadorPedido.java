package co.edu.udistrital.model;

//Interface con la que se comunica el cliente
public interface ProcesadorPedido {
	
	
	String enviarPedido(String pedido);

}
