package co.edu.udistrital.model;

public class Rappi {
	
	//Método que envia el pedido a rappi
	public String RappienviarPedido(String json) {
		
		return("[Rappi] Enviando JSON: " + json);
	}

}
